import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { PlusIcon, PlayIcon, PauseIcon, TrashIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: 'draft' | 'deploying' | 'active' | 'failed' | 'archived';
  node_count: number;
  total_executions: number;
  success_rate: number;
  last_run: string | null;
  created_at: string;
}

export default function Dashboard() {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    loadUserData();
    loadWorkflows();
  }, []);

  const loadUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        
        setUser({ ...user, profile });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadWorkflows = async () => {
    try {
      const { data, error } = await supabase
        .from('user_workflows')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWorkflows(data || []);
    } catch (error: any) {
      toast.error('Failed to load workflows');
      console.error('Error loading workflows:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/10';
      case 'failed': return 'text-red-400 bg-red-400/10';
      case 'deploying': return 'text-yellow-400 bg-yellow-400/10';
      case 'draft': return 'text-gray-400 bg-gray-400/10';
      case 'archived': return 'text-gray-500 bg-gray-500/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse">
          <div className="h-8 w-8 border-2 border-white/20 border-t-white rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold font-mono">Dashboard</h1>
          <p className="text-zinc-400 mt-1">
            Manage your AI-powered n8n workflows
          </p>
        </div>
        <Link
          to="/chat"
          className="bg-white text-black px-4 py-2 rounded-md text-sm font-medium hover:bg-white/90 transition-colors flex items-center space-x-2"
        >
          <PlusIcon className="w-4 h-4" />
          <span>Create Workflow</span>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-zinc-900/50 border border-white/10 rounded-lg p-6">
          <div className="text-sm font-medium text-zinc-400">Total Workflows</div>
          <div className="text-2xl font-bold mt-1">{workflows.length}</div>
        </div>
        <div className="bg-zinc-900/50 border border-white/10 rounded-lg p-6">
          <div className="text-sm font-medium text-zinc-400">Active</div>
          <div className="text-2xl font-bold mt-1 text-green-400">
            {workflows.filter(w => w.status === 'active').length}
          </div>
        </div>
        <div className="bg-zinc-900/50 border border-white/10 rounded-lg p-6">
          <div className="text-sm font-medium text-zinc-400">Total Executions</div>
          <div className="text-2xl font-bold mt-1">
            {workflows.reduce((sum, w) => sum + w.total_executions, 0)}
          </div>
        </div>
        <div className="bg-zinc-900/50 border border-white/10 rounded-lg p-6">
          <div className="text-sm font-medium text-zinc-400">Success Rate</div>
          <div className="text-2xl font-bold mt-1">
            {workflows.length > 0 
              ? Math.round(workflows.reduce((sum, w) => sum + w.success_rate, 0) / workflows.length)
              : 0
            }%
          </div>
        </div>
      </div>

      {/* Workflows List */}
      <div className="bg-zinc-900/50 border border-white/10 rounded-lg">
        <div className="px-6 py-4 border-b border-white/10">
          <h2 className="text-lg font-semibold">Your Workflows</h2>
        </div>
        
        {workflows.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-zinc-500 mb-4">
              <PlusIcon className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium mb-2">No workflows yet</h3>
            <p className="text-zinc-400 mb-4">
              Create your first AI-powered n8n workflow to get started.
            </p>
            <Link
              to="/chat"
              className="bg-white text-black px-4 py-2 rounded-md text-sm font-medium hover:bg-white/90 transition-colors inline-flex items-center space-x-2"
            >
              <PlusIcon className="w-4 h-4" />
              <span>Create Workflow</span>
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-white/10">
            {workflows.map((workflow) => (
              <div key={workflow.id} className="px-6 py-4 hover:bg-white/5 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-3">
                      <h3 className="text-sm font-medium text-white truncate">
                        {workflow.name}
                      </h3>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(workflow.status)}`}>
                        {workflow.status}
                      </span>
                    </div>
                    <p className="text-sm text-zinc-400 mt-1 truncate">
                      {workflow.description}
                    </p>
                    <div className="flex items-center space-x-6 mt-2 text-xs text-zinc-500">
                      <span>{workflow.node_count} nodes</span>
                      <span>{workflow.total_executions} executions</span>
                      <span>{workflow.success_rate}% success rate</span>
                      {workflow.last_run && (
                        <span>Last run: {formatDate(workflow.last_run)}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    {workflow.status === 'active' ? (
                      <button className="p-2 text-zinc-400 hover:text-white transition-colors" title="Pause workflow">
                        <PauseIcon className="w-4 h-4" />
                      </button>
                    ) : (
                      <button className="p-2 text-zinc-400 hover:text-white transition-colors" title="Start workflow">
                        <PlayIcon className="w-4 h-4" />
                      </button>
                    )}
                    <button className="p-2 text-zinc-400 hover:text-red-400 transition-colors" title="Delete workflow">
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="bg-zinc-900/50 border border-white/10 rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            to="/chat"
            className="flex items-center p-4 border border-white/10 rounded-lg hover:bg-white/5 transition-colors"
          >
            <PlusIcon className="w-6 h-6 mr-3" />
            <div>
              <h3 className="font-medium">Create New Workflow</h3>
              <p className="text-sm text-zinc-400">Use AI to generate a new n8n workflow</p>
            </div>
          </Link>
          <button className="flex items-center p-4 border border-white/10 rounded-lg hover:bg-white/5 transition-colors text-left">
            <PlayIcon className="w-6 h-6 mr-3" />
            <div>
              <h3 className="font-medium">View Analytics</h3>
              <p className="text-sm text-zinc-400">Monitor workflow performance and usage</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}